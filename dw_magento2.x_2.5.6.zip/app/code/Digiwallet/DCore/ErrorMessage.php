<?php
namespace Digiwallet\DCore;

use Digiwallet\DCore\DigiwalletCore;

/**
 * @file Provides support for Digiwallet iDEAL, Mister Cash and Sofort Banking
 *
 * @author Yellow Melon B.V.
 *         @url http://www.idealplugins.nl
 *         @release 29-09-2014
 *         @ver 2.5
 *
 *         Changes:
 *
 *         v2.1 Cancel url added
 *         v2.2 Verify Peer disabled, too many problems with this
 *         v2.3 Added paybyinvoice (achteraf betalen) and paysafecard (former Wallie)
 *         v2.4 Removed IP_range and deprecated checkReportValidity . Because it is bad practice.
 *         v2.5 Added creditcards by ATOS
 */

/**
 * @class Digiwallet Core class
 */
class ErrorMessage
{
    /**
     * List of error messages returned from API
     * @var array
     */
    const API_ERRORS = array(
        'DW_SE_0020 Transaction has not been completed, try again later' => array(
            'en' => 'Transaction has not yet been completed, try again later',
            'nl' => 'Transactie niet compleet, probeer later opnieuw'
        ),
        'DW_SE_0021 Transaction has been cancelled' => array(
            'en' => 'Transaction has been cancelled',
            'nl' => 'Transactie geannuleerd'
        ),
        'DW_SE_0022 Transaction has expired' => array(
            'en' => 'Transaction has expired (max. 10 minutes)',
            'nl' => 'Transactie is verlopen (max. 10 minuten)'
        ),
        'DW_SE_0023 Transaction could not be processed' => array(
            'en' => 'The transaction could not be processed',
            'nl' => 'Transactie kan niet worden uitgevoerd',
        ),
        'DW_SE_0028 Transaction already checked at' => array(
            'en' => 'Already redeemed',
            'nl' => 'Transactie al gecheckt'
        ),
        'DW_XE_0003 Validation failed, details' => array(
            'en' => 'One or more fields failed to validate, you can decode the JSON array for a detailed analysis.',
            'nl' => 'Validatie mislukt'
        ),
        'DW_IE_0002 Maximum retries at acquirer bank exceeded for primary and fallback' => array(
            'en' => 'The acquirer system did not respond multiple times in a row, indicating there might be a service disruption going on.',
            'nl' => 'Bank reageert niet'
        ),
        'DW_IE_0006 System is busy, please retry later' => array(
            'en' => 'Internal systems are overloaded and DigiWallet is likely already working on resolving the problem.',
            'nl' => 'Systeem bezet, probeer later opnieuw'
        ),
        'DW_IE_0001 Unknown internal error' => array(
            'en' => 'Unknown internal error, mail to techsupport@targetmedia.eu to be sorted out.',
            'nl' => 'Onbekende fout, mail naar techsupport@targetmedia.eu voor een oplossing'
        )
    );

    /**
     * Get error message from APIs
     * @param $key
     * @param string $language
     * @return mixed
     */
    public static function getErrorMessage($key, $language = 'en') {
        foreach (self::API_ERRORS as $message_key => $messages) {
            if (strpos($key, $message_key) !== false) {
                if(isset($messages[$language])) {
                    return $messages[$language];
                }
            }
        }
        // Return origin message if no matching found
        return $key;
    }
}
